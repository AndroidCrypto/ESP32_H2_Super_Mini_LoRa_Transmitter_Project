#pragma once

#ifndef __has_include
#define FL_HAS_INCLUDE(x) 0
#else
#define FL_HAS_INCLUDE(x) __has_include(x)
#endif
