#include "fl/gamma.h"

namespace fl {

// gamma_2_8 lookup table has been moved to fl/ease.cpp.hpp
// This file is kept for compatibility with the build system

} // namespace fl
